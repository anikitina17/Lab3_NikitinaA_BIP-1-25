﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_NikitinaA
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter x: ");
            double x = double.Parse(Console.ReadLine());

            // 1 завдання: y = sqrt(cos(x)), якщо cos(x) >= 0
            double cosValue = Math.Cos(x);
            if (cosValue >= 0)
            {
                double y = Math.Sqrt(cosValue);
                Console.WriteLine("y = sqrt(cos(x)) = {0}", Math.Round(y, 5));
            }
            else
            {
                Console.WriteLine("y = sqrt(cos(x)) не існує, бо cos(x) < 0");
            }

            // 2 завдання: y = |cos(x) + 1|
            double y1 = Math.Abs(cosValue + 1);
            Console.WriteLine("y1 = |cos(x) + 1| = {0}", Math.Round(y1, 5));

        }

    }
}
